
plugins {
    kotlin("jvm") version "2.2.20"
    kotlin("plugin.serialization") version "2.2.20"

}

tasks {
    jar {
        manifest {
            attributes["Main-Class"] = "MCO2_KotlinKt"
        }
        val dependencies = configurations
            .runtimeClasspath
            .get()
            .map(::zipTree)
            from(dependencies)
            duplicatesStrategy = DuplicatesStrategy.EXCLUDE
            archiveFileName.set("MCO2_KOTLIN.jar")
	    destinationDirectory.set(layout.projectDirectory)
    }

}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(kotlin("test"))
    implementation("org.jetbrains.kotlinx:dataframe:1.0.0-Beta3")
    implementation("org.jetbrains.kotlin:kotlin-stdlib:2.2.20")
    implementation("org.slf4j:slf4j-simple:2.0.12")
}

tasks.test {
    useJUnitPlatform()
}
kotlin {
    jvmToolchain(24)
}